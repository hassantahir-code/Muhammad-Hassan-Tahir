import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import { readFaqs, saveFaqs, nextFaqId } from '../services/faqStore.js';
import { CATEGORIES, STARTER_FAQS } from '../utils/constants.js';
import { requireAdmin } from '../middleware/adminAuth.js';
const router=Router();
router.post('/login',(req,res)=>{
 const pin=req.body?.pin;
 if(typeof pin!=='string' || pin !== (process.env.ADMIN_PIN || '2026')) return res.status(401).json({error:'Incorrect PIN'});
 const token=randomBytes(32).toString('hex'); req.app.locals.adminSessions.add(token); res.json({token});
});
router.use(requireAdmin);
router.post('/faqs',async(req,res,next)=>{
 try {
  const {question,answer,category}=req.body||{};
  if(typeof question!=='string'||question.trim().length<10||question.trim().length>150) return res.status(400).json({error:'Question must be 10–150 characters.'});
  if(typeof answer!=='string'||answer.trim().length<10||answer.trim().length>400) return res.status(400).json({error:'Answer must be 10–400 characters.'});
  if(!CATEGORIES.includes(category)) return res.status(400).json({error:'Select an approved category.'});
  const faqs=await readFaqs(); const faq={id:nextFaqId(faqs),category,question:question.trim(),answer:answer.trim()};
  faqs.push(faq); await saveFaqs(faqs); res.status(201).json({faq,faqs});
 }catch(e){next(e);}
});
router.delete('/faqs/:id',async(req,res,next)=>{
 try { const faqs=await readFaqs(); const next=faqs.filter(f=>f.id!==req.params.id); if(next.length===faqs.length)return res.status(404).json({error:'FAQ not found.'}); await saveFaqs(next); res.json({faqs:next}); }catch(e){next(e);}
});
router.post('/reset',async(_req,res,next)=>{try{await saveFaqs(STARTER_FAQS);res.json({faqs:STARTER_FAQS});}catch(e){next(e);}});
export default router;
