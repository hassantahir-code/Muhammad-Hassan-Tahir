import { NOT_FOUND } from '../utils/constants.js';
export function validateStudentQuestion(value) {
  return typeof value === 'string' && value.trim().length >= 1 && value.length <= 300;
}
export function validateModelAnswer(result, faqs) {
  if (!result || typeof result.found !== 'boolean' || typeof result.answer !== 'string' || !Array.isArray(result.faq_ids)) return {found:false,answer:NOT_FOUND,faq_ids:[]};
  if (!result.faq_ids.every(id => typeof id === 'string')) return {found:false,answer:NOT_FOUND,faq_ids:[]};
  const known = new Set(faqs.map(f => f.id));
  const ids = [...new Set(result.faq_ids)];
  if (!result.found || ids.length === 0 || !ids.every(id => known.has(id)) || !result.answer.trim()) return {found:false,answer:NOT_FOUND,faq_ids:[]};
  return {found:true,answer:result.answer.trim(),faq_ids:ids};
}
