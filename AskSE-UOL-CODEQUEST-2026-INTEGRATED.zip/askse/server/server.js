import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import chatRouter from './routes/chat.js';
import faqRouter from './routes/faqs.js';
import adminRouter from './routes/admin.js';
import { ensureStarterData } from './services/faqStore.js';

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const clientDist = path.resolve(here, '../client/dist');
app.locals.adminSessions = new Set();
const PORT = Number(process.env.PORT || 5000);
const allowedOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

await ensureStarterData();
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? allowedOrigin : [allowedOrigin, 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'x-admin-token'],
}));
app.use(express.json({ limit: '12kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'AskSE API' }));
app.use('/api/chat', chatRouter);
app.use('/api/faqs', faqRouter);
app.use('/api/admin', adminRouter);

// In production, Express hosts both the React app and API on one origin.
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(clientDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.use((err, _req, res, _next) => {
  console.error('Request error:', err?.message || 'unknown');
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});
app.listen(PORT, () => console.log(`AskSE server listening on http://localhost:${PORT}`));
