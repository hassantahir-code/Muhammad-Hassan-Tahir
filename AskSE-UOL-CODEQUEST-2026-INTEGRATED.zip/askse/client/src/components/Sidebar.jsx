import {MessageSquarePlus,MessagesSquare,ShieldCheck,Info,PanelLeftClose,PanelLeftOpen,GraduationCap} from 'lucide-react';
export default function Sidebar({collapsed,setCollapsed,conversations,activeId,setActiveId,newChat,page,setPage}){
 return <aside className={`sidebar ${collapsed?'sidebar-collapsed':''}`}>
  <div className="brand-row"><div className="brand-mark"><GraduationCap size={22}/></div>{!collapsed&&<div><div className="brand-name">AskSE<span>.</span></div><div className="brand-sub">DEPARTMENT HELP DESK</div></div>}<button className="icon-btn collapse-btn" onClick={()=>setCollapsed(!collapsed)} aria-label="Toggle sidebar">{collapsed?<PanelLeftOpen size={18}/>:<PanelLeftClose size={18}/>}</button></div>
  <button className="new-chat" onClick={newChat}><MessageSquarePlus size={17}/>{!collapsed&&'New chat'}</button>
  {!collapsed&&<div className="side-label">WORKSPACE</div>}
  <button className={`nav-item ${page==='chat'?'active':''}`} onClick={()=>setPage('chat')}><MessagesSquare size={17}/>{!collapsed&&'Chat'}</button>
  {!collapsed&&<div className="side-label history-label">RECENT CHATS</div>}
  <div className="history-list">{conversations.map(c=><button key={c.id} className={`history-item ${activeId===c.id&&page==='chat'?'selected':''}`} title={c.title} onClick={()=>{setActiveId(c.id);setPage('chat')}}><span className="history-dot"/>{!collapsed&&(c.title||'New chat')}</button>)}</div>
  <div className="sidebar-bottom"><button className={`nav-item ${page==='admin'?'active':''}`} onClick={()=>setPage('admin')}><ShieldCheck size={17}/>{!collapsed&&'Admin panel'}</button><button className={`nav-item ${page==='about'?'active':''}`} onClick={()=>setPage('about')}><Info size={17}/>{!collapsed&&'About AskSE'}</button>{!collapsed&&<div className="sidebar-foot"><span className="status-dot"/> Department knowledge base</div>}</div>
 </aside>
}
