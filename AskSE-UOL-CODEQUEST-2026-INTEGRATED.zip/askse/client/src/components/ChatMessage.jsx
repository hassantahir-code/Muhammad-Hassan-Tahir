import {Bot,User,Copy,Check,ThumbsUp,ThumbsDown} from 'lucide-react';
import {useState} from 'react';
import {timeLabel} from '../hooks/useChat';
export default function ChatMessage({message}){
 const [copied,setCopied]=useState(false);
 const copy=async()=>{await navigator.clipboard?.writeText(message.content);setCopied(true);setTimeout(()=>setCopied(false),1200)};
 return <div className={`message-row ${message.role==='user'?'user-row':''}`}><div className={`avatar ${message.role==='user'?'user-avatar':'bot-avatar'}`}>{message.role==='user'?<User size={17}/>:<Bot size={18}/>}</div><div className="message-body"><div className="message-meta"><strong>{message.role==='user'?'You':'AskSE'}</strong><span>{timeLabel(message.timestamp)}</span></div><div className={`message-bubble ${message.role==='user'?'user-bubble':'bot-bubble'}`}>{message.content}</div>{message.role==='assistant'&&message.faq_ids?.length>0&&<div className="citations"><span className="citation-label">SOURCES</span>{message.faq_ids.map(id=><span className="citation-chip" key={id}>↗ {id}</span>)}</div>}{message.role==='assistant'&&<div className="message-actions"><button onClick={copy}>{copied?<Check size={13}/>:<Copy size={13}/>} {copied?'Copied':'Copy'}</button><button title="Helpful"><ThumbsUp size={13}/></button><button title="Not helpful"><ThumbsDown size={13}/></button></div>}</div></div>
}
